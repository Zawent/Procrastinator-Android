package com.micasa.holamundo.pregunta;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.micasa.holamundo.R;
import com.micasa.holamundo.model.Pregunta;
import com.micasa.holamundo.model.User;
import com.micasa.holamundo.network.PreguntaAPICliente;
import com.micasa.holamundo.network.PreguntaAPIService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Pregunta1Activity extends AppCompatActivity {

    private PreguntaAPIService service;
    Pregunta pregunta1;
    User user;
    TextView ola;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pregunta1);
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("user");
        service = PreguntaAPICliente.getPreguntaService();
        service.getOne(1).enqueue(new Callback<Pregunta>() {
            @Override
            public void onResponse(Call<Pregunta> call, Response<Pregunta> response) {
                Log.i("ola1",""+response.body());
                if (response.isSuccessful()) {
                    Log.i("ola","si");
                    pregunta1 = response.body();

                    ola = findViewById(R.id.textViewPregunta1);
                    ola.setText(pregunta1.getDescripcion_pregunta());
                }
            }

            @Override
            public void onFailure(Call<Pregunta> call, Throwable t) {
                Log.i("ola","no");
            }
        });


    }



}