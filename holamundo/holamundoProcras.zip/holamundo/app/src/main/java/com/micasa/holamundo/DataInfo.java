package com.micasa.holamundo;

import com.micasa.holamundo.model.RespuestaLogin;

public class DataInfo {

    public static RespuestaLogin respuestaLogin = null;
}
